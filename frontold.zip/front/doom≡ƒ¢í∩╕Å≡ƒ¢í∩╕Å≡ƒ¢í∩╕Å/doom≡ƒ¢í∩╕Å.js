import {lazyANM,assLoaded, setVID, cleanVID,
  videoPromise,
  imgPromise,lazyFn,loadFn,
  setLZY

} from './loads.js'

import {
  vidclickFn
} from './fns.js'
 




export class doom {

  constructor(mediaQueries = {},main) {

    const style = getComputedStyle(document.documentElement)
  
    const touch = style.getPropertyValue('--touch')
    const mvMax = style.getPropertyValue('--mobileMax')

    this.mediaQueries = {
      // isPT : '(var(--mobileMax) < width <= var(--touch)) and (min-aspect-ratio: 1.2)'
      // isPT : '(max-width:1140px)',
      isPT: `(width < ${touch}) and (max-aspect-ratio: 1.2)`,
      isLD: `(width < ${touch}) and (min-aspect-ratio: 1.2)`,
      isMobile: `(${mvMax} >= width)`,
      isTouch: `(hover: none)`,
      

    }

    this.mediaQueries =  { ...this.mediaQueries, ...mediaQueries }
    this.main = main

    this.SCR = [
      window.innerWidth,
      window.innerHeight
    ]

    const heightHandler = this.main.querySelectorAll('.hOBRs')
    if(heightHandler){

        this.resizeObserver = new ResizeObserver(entries => {
          entries.forEach(entry => {

            const slave = entry.target.closest('.hOBRs')

            // console.log(entry)
            // console.log(entry.target)
            // console.log(slave)
            // console.log('Size changed:', entry.contentRect)
            // console.log(entry.target.clientHeight)
            anime.utils.set(slave,{'--hMaster':entry.target.clientHeight+'px'})

          })

        })

        for(let a of this.main.querySelectorAll('.hOBRs')){

            this.resizeObserver.observe(a.querySelector('.hOBRm'))

        }
    }

    this.setLZY()
  }

  
  //SCOPES

  setSCP(ops = new Map()){


    // console.log('set SCP')
    this.SCP = anime.createScope({
      // root,
      mediaQueries : this.mediaQueries
    })

    
    .add(self =>{

        // console.log('launch SCP')
        const { 
          isMobile,
          isTouch,
          isPT
        } = self.matches
        
        
        // if(foot){

        //   anime
        //   .animate(foot,{
        //     translateY:
        //     {from:-100+'%',to:0+'%',duration:5},
        //     ease:'linear(0, 0.5, 1)',
        //     autoplay:anime.onScroll({
        //       sync:.99,
        //       // debug:true,
        //       target:foot.parentNode,
        //       enter:'bottom top',
        //       leave:'bottom bottom',
        //     })

        //   })
        // }

    })


  }

  async killSCP(){
    //💡 Matar el SCP para que no trabaje, antes del pop? 
    this.SCP.revert()
    this.LZY.revert()

  }
  //END SCOPES

  intro( ops = new Map(), resolve = null ){

    this.LZY.methods.lazy()
    
  }

  // Se lanza cuando entra el pop con RVL
  outroLDR(ops = new Map(),resolve = null ){
    // console.log('launch outro LDR')
    resolve != null ? resolve() : null

  }


  // Se lanza cuando entra el popApp
  outro(ops = new Map(),resolve = null ){
    // console.log('launch outro')

    const VIDs = document.querySelectorAll('video')

    for(let vid of VIDs){
      vid.pause()
    }

    const ANM = anime.createTimeline({
      autoplay:false,
      onComplete:()=>{
        
        resolve != null ? resolve() : null

      }
    })
    .add(this.main,{
      opacity:0,
      duration:.6,
      composition:'replace',
    },0)
    .init()

    resolve != null ? resolve() : null

    return ANM
  }

  // Último paso, por si se queda algo por rematar
  kill(){
    // console.log('launch kill')

    if(this.slides){
      for(let a of this.slides){
        a.onAfterResize = ()=>
        a.revert()
      }
    }
    if(this.snaps){
      for(let a of this.snaps){
        a.onAfterResize = ()=>
        a.revert()
      }
    }


    this.main.remove()
    this.SCP.revert()


  }


  resizeFn(){

    


  }
  
}



doom.prototype.lazyFn = lazyFn
doom.prototype.loadFn = loadFn
doom.prototype.vidclickFn = vidclickFn
doom.prototype.setLZY = setLZY
