import { 
  setVID,
  cleanVID
} from './loads.js'



export function vidclickFn({anm,ass, enter='bottom', leave=false}){

    // 💡 Si tiene botón, con botón, si no, al video
    const clicker = 
      ass.parentNode.querySelector('.vidClick') ? ass.parentNode.querySelector('.vidClick') : ass
    
    // setVID(ass)
    ass.oncanplay = () => {

      if (ass.isPlaying) {
        ass.classList.add('L')
        cleanVID(ass)
      }

    }
    clicker.onclick = () =>{

      if(ass.dataset.src){
        setVID(ass)
        ass.src = ass.dataset.src
        delete ass.dataset.src

        ass.muted = false
      }
      
      ass.paused == true ? 
      [ass.play(),ass.classList.add('run'),anm.play()] : 
      [ass.pause(),ass.classList.remove('run')]

    }

    return anime.animate(ass, {
      duration: 0,
      autoplay: anime.onScroll({
        enter,
        leave,
        onLeave:(self) => {
          ass.paused == false ? [ass.pause(),ass.classList.remove('run')] : false
        }
      })

    })

  }