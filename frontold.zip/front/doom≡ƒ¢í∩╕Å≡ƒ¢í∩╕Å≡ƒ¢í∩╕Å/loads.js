import {swiftOut,timeout} from '/front/js🧠🧠🧠/🔧utils.js'

import {lazyanm} from './anm.js'




export  function lazyANM (ass,type='default') {
  
  const anmFn = lazyanm.has(type) ? lazyanm.get(type) : lazyanm.get('default')
  const anm = anmFn(ass)

  return anm

}

export const assLoaded = ( el ) => {

  el.tagName == 'IMG' ? el.removeAttribute('loading') : el.setAttribute('loading','true')

}

function setCtr(ass){
  if(ass.parentNode.querySelector('.vCtrl_mute')){
    const muteCtr = ass.parentNode.querySelector('.vCtrl_mute')
    muteCtr.onclick = () =>{


      muteCtr.classList.contains('A') ?
      [muteCtr.classList.remove('A'), ass.muted = false] 
      : [muteCtr.classList.add('A'), ass.muted = true]


    }
  }



  if(ass.parentNode.querySelector('.vCtrl_pl')){
    const mutePL = ass.parentNode.querySelector('.vCtrl_pl')
    mutePL.onclick = () =>{


      mutePL.classList.contains('A') ?
      [mutePL.classList.remove('A'), ass.pause()] 
      : [mutePL.classList.add('A'), ass.play()]


    }
  }
}

//🧪🧪🧪🧪
export function setlazyVID(ass,resolve = null){
  ass.setAttribute('webkit-playsinline', 'webkit-playsinline')
  ass.setAttribute('playsinline', 'playsinline')
  ass.muted = true
  ass.autoplay = true
  ass.loop = true

  if(ass.parentNode.querySelector('.vCtrl_mute')){
    setCtr(ass)
  }

  resolve()
}

export function setVID(ass,resolve = null){


  ass.setAttribute('webkit-playsinline', 'webkit-playsinline')
  ass.setAttribute('playsinline', 'playsinline')
  ass.muted = true
  ass.autoplay = true
  ass.loop = true
  //🚧🚧🚧🚧🚧
  setCtr(ass)
  

  ass.onplay = () => {

    ass.isPlaying = true
  }
  // ass.oncanplay = () => {
  //   ass.pause()
  //   ass.isPlaying = true
  //   console.log('mayot rolo')
  // }
  // ass.onloadeddata = () => {
  //   ass.pause()
  //   ass.isPlaying = true
  
    
  //   console.log(ass.readyState) 
    
  // }
  // ass.onloadstart = () => {
  //   ass.pause()
  //   ass.isPlaying = true
  
  //   console.log(ass.readyState) 
  // }
  // ass.oncanplaythrough = () => {
  //   ass.pause()
  //   ass.isPlaying = true

  //   ass.oncanplaythrough = null
  
  //   console.log(ass.readyState)
  // }
  
  ass.pause()
  
  if(ass.readyState == 4){
    
    
    resolve != null ? resolve() : null
  }

  else{
    ass.oncanplay = () => {

      ass.pause()
      ass.isPlaying = true
  
     
      
      // resolve != null ? setTimeout(()=>resolve(),64) : null
      resolve != null ? resolve() : null
      delete ass.dataset.src
      // resolve != null ? setTimeout(()=>resolve(),160) : null
  
      ass.oncanplay = null
    }
  }

  
  ass.src = ass.dataset.src ? ass.dataset.src : ass.src
  if(ass.dataset.src) ass.load()
  // ass.load()
}

export function cleanVID(ass){

  ass.oncanplay = null
  ass.onplay = null
  ass.currentTime= 0

  let isPlaying = ass.currentTime > 0 && !ass.paused && !ass.ended 
  && ass.readyState > ass.HAVE_CURRENT_DATA

}





export function videoPromise(vid){
  
  return new Promise((resolve, reject) => {
        
    if(vid.getAttribute('src')){



      resolve(vid)
      return false
    }

    setVID(vid)

    vid.oncanplay = () => {
      if (vid.isPlaying) {
        vid.classList.add('L')
        vid.pause()

        cleanVID(vid)
        resolve(vid)
      }
    }
    
    vid.src = vid.dataset.src
    delete vid.dataset.src
    
    vid.onerror = () =>{
      resolve(vid)
    }
    
    vid.play()

  })

}


export function imgPromise(img){
  
  return new Promise((resolve, reject) => {
    
  const url = img.dataset.src


  const fakeimg = new Image()
  fakeimg.onload = () => {
    // img.src = url
    img.srcset = url
    resolve(fakeimg)
  }
  fakeimg.onerror = () => {
    resolve(img)
  }
  // fakeimg.src = url
  fakeimg.srcset = url


  })

}

export async function lazyFn({ass,anm, enter='bottom', leave=false}){
  // 💡 Función de entrada del elemento en pantalla
  // ass.tagName == 'VIDEO' ? setVID(ass) : null
  
  return anime.animate(ass, {

      duration: 0,
      autoplay: anime.onScroll({
        enter,
        leave:'top bottom',
          // sync: true,
        onEnter: (self) => {
          // ass.animed = ass.dataset.xx == 'none' ? true : false
          ass.animed = false
          if(!ass.hasAttribute('loading') ) return false
          

          if(ass.complete == false || ( ass.dataset.src || ass.getAttribute('loading') == 'none' )){
            
            anm.onStart = assLoaded(ass)
            anm.onComplete = (self) => {
              ass.animed = true
              if(ass.dataset.xx == 'none') {

                anime.utils.cleanInlineStyles(self)
                // return false
              
              }
            }
            const assTypeLd = ass.tagName == 'VIDEO' ? 'onplay' :  'onload'
            
            ass[assTypeLd] = () => {

              // if(ass.tagName == 'VIDEO' ){
                
                // if (ass.isPlaying) {
                //   ass.classList.add('L')
                // }
              // }
              if(ass.tagName == 'VIDEO') {
                ass[assTypeLd] = null
                ass['onplay'] = null
              }
              anm.play()
              delete ass.dataset.src
              
              
            }

            if(ass.tagName == 'VIDEO'){

              // ass.src = ass.dataset.src
              // delete ass.dataset.src
                  
              let isHov = Array.from(ass.classList).filter(
                (c) =>{ 
                  // console.log(c)
                  if(c.startsWith('hov_')){ 
                    return c
                  }
                })
              
              isHov = isHov.length == 0 ? undefined : isHov[0]

              


              if(isHov){
                const checkHov = isHov.substr(4)
                let pointerHov = Number.isInteger(parseInt(checkHov.substr(4))) ? parseInt(checkHov.substr(4)) : checkHov
                

                let hoverctr = ass.classList.contains('hov') ? 
                // el mismo elemento hace el hover
                ass : 
                // por capas, según el número, hace distintos parentsnodes
                Number.isInteger(pointerHov) ?
                ()=> {
                  let parenting = ass
                  for(let i=0;i<pointerHov;i++){

                    parenting=parenting.parentNode

                  }

                  return parenting
                }
                // por búsqueda de clase. 
                : ()=>{
                  return document.querySelector('.'+checkHov) ? document.querySelector('.'+checkHov) : ass
                }

                hoverctr = (typeof hoverctr === 'function' ) ? hoverctr() : hoverctr
                // console.log(hoverctr)

                hoverctr.onmouseenter = () =>{
                  ass.play()
                }

                hoverctr.onmouseleave = () =>{
                  ass.pause()
                }

                ass.play()
                ass.removeAttribute('loading')
                ass.pause()

                return false
              }
              else if(!ass.classList.contains('noplay')){
                ass.play()

              }
              

              
            }
            
            //GL para TX
            // ass.onload = () => {

            // }

          }
          else{

            ass.tagName == 'VIDEO' ? [ ass.play(),ass.currentTime = 0 ] : undefined
            ass.animed == false ? anm.play() : anm.complete()

          }
        
        },
        onLeave: () => {

          ass.tagName == 'VIDEO' ? [ass.pause(),ass.muted = true] : undefined

        },
        // onUpdate: () => {},
      })
    })
}

export async function loadFn(first = 0,hold = false){

  const PROMs =[]

  hold = hold == false ? this.main : hold

  const IMGwait = first == 0 ? hold.querySelectorAll('img.WT') : document.querySelectorAll('img.WT')
  const VIDwait = first == 0 ? hold.querySelectorAll('video.WT') : document.querySelectorAll('video.WT')
  const VIDEOlazy = first == 0 ? hold.querySelectorAll('video[loading="none"][data-auto="true"]') : document.querySelectorAll('video[loading="none"][data-auto="true"]')
  // VIDEO LAZY SET THAN
  
  for(let ass of VIDEOlazy){
    //🧪🧪🧪🧪🧪
    // el que funciona siempre es el setVid, pero es verdad que si hay muchos, rasca
    const LazySetProm = new Promise((resolve, reject) => setVID(ass,resolve))
    // const LazySetProm = new Promise((resolve, reject) => setlazyVID(ass,resolve))
    // const LazySetProm = new Promise((resolve, reject) => {
    //   ass.pause()
    //   resolve()
    // })
    PROMs.push(LazySetProm)

  }
  // const LazySetProm = await Promise.all(lazySet)

  // console.log(performance.now())
  //HACER IMG WAIT
  for(let img of IMGwait){
    
    const PROM = imgPromise(img)
    PROMs.push(PROM)

  }

  //HACER VIDEO WAIT
  for(let vid of VIDwait){

    const PROM = videoPromise(vid)
    PROMs.push(PROM)

  }

  // *.WT promises wait
  await Promise.all(PROMs)


  // console.log(performance.now())
}



export function setLZY(){

    this.LZY = anime.createScope({
      // root,
    })
    .add(self =>{
    self.add('lazy', (e,elemhold = document) => {
        
        const isPT = window.matchMedia('(width < 1024px) and (max-aspect-ratio: 1.2)').matches


        //💡 Cargas lazy de videos, imágenes, clicks en videos, entrada y salida de videos.
        const ASSlazy = elemhold.querySelectorAll('img[loading="lazy"],video[loading="none"]')
        const VIDwait = elemhold.querySelectorAll('video.WT')

        // if(elemhold != document){
          // console.log(ASSlazy)
          // console.log(VIDwait)
        // }

        

      //LAZY IMG y VIDs, click VID
      for(let ass of ASSlazy){
        
        const checkANM = ass.dataset.xx ?? 'default'

        const anm = lazyANM(ass,ass.dataset.xx ?? 'default')

        const enter = isPT & ass.dataset.enterpt ? ass.dataset.enterpt :
        ass.dataset.enter ? ass.dataset.enter : 'bottom top'
        
        ass.dataset.auto && ass.dataset.auto == 'click' ? this.vidclickFn({anm,ass}) : this.lazyFn({ass,anm,enter:enter ?? undefined})

      }


        // video.WT out stop
        for(let ass of VIDwait){
          
          anime.animate(ass, {
            // opacity:[0,0],
            duration: 0,
            // axis: ass.parentNode.classList.contains('.slide_el') ? 'x' : 'y',
            autoplay: anime.onScroll({
              enter: 'bottom top',
                // sync: true,
              onEnter: (self) => {
                if(!ass.classList.contains('noplay')){
                   ass.play()
                }


              },

              onLeave:(self) =>{
                ass.pause()
              }

            })

          })

        }


      })

    })
  }