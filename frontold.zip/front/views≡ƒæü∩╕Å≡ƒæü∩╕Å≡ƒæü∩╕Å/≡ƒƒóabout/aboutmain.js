import {doom} from '/front/doom🛡️🛡️🛡️/doom🛡️'

import Splide from '@splidejs/splide'

// import {Sld} from '/front/comps🦾🦾🦾/slider🎞️snap.js'

//ANIMS
import {linesShow,elY100,hovANM} from '/front/doom🛡️🛡️🛡️/anm.js'
import {swiftOut,timeout} from '/front/js🧠🧠🧠/🔧utils.js'
import { stagger } from 'animejs'

// import { getSkin } from '/front/start🏁🏁🏁/load🧱.js'

export class about extends doom {
  constructor(el) {

    // const style = getComputedStyle(document.documentElement)
    

    const mediaQueries = {
    }

    const main = el
    super(mediaQueries,main)


  }

  intro( ops = new Map(), resolve = null ){

    //Ops needs
    const first = ops.get('first')
    // const lenis = ops.get('lenis')

    this.DOM = {
     
    }
    




    

    const ANM = anime.createTimeline({
      autoplay:false,
      // delay:first == 1 ? 1 : 0,
      onComplete:()=>{
        
      }
      
    })
    .add(this.main,{
      opacity: [0, 1],
      duration: 1,
      ease: 'inOut(2)',

    },0)
    .init()


    return ANM
    // resolve != null ? ANM.play() : null
  }


  setSCP(){
    //💡 Genera el Scope
    super.setSCP()

    this.SCP
    .add(self =>{

      const {
        isPT,
        isMobile,
        isTouch
      } = self.matches

      

    })

  }




  resizeFn(){
    super.resizeFn()

  }
}
