import {doom} from '/front/doom🛡️🛡️🛡️/doom🛡️'


import {Sld} from '/front/comps🦾🦾🦾/slider🎞️.js'

//ANIMS
import {linesShow,elY100,hovANM} from '/front/doom🛡️🛡️🛡️/anm.js'
import {swiftOut,timeout} from '/front/js🧠🧠🧠/🔧utils.js'

export class page extends doom {
  constructor(el) {

    const style = getComputedStyle(document.documentElement)
    const padgut = style.getPropertyValue('--padgut')
    

    const mediaQueries = {
      // isabout: `(${padgut} >= width)`,
    }

    const main = el
    super(mediaQueries,main)


   

  }

  intro( ops = new Map(), resolve = null ){

    const first = ops.get('first')

    this.DOM = {

    }
    

    const ANM = anime.createTimeline({
      autoplay:false,
      // delay:first == 1 ? 1 : 0,
      onComplete:()=>{
        
        resolve != null ? resolve() : null

      }
      
    })
    .add(this.main,{
      opacity:[0,1],
      duration:first == 1 ? 0 : 1,
      delay:first == 1 ? 1 : 0,
    },0)
    
    .init()

    
    if(resolve == null){
      return ANM
    }
    else{
      ANM.init()
    }

  }


  setSCP(){

    


    //💡 Genera el Scope
    super.setSCP()


    this.SCP
    .add(self =>{

        const { 
          isMobile,
          isTouch
        } = self.matches







       

    })




  }



  resizeFn(){
    super.resizeFn()



  }
}
