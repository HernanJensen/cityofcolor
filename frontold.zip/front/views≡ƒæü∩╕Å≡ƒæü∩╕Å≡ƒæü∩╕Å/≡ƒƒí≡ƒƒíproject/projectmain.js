import {doom} from '/front/doom🛡️🛡️🛡️/doom🛡️'


import Video from '/front/comps🦾🦾🦾/videoCtrls.js'

//ANIMS
import {linesShow,elY100,hovANM} from '/front/doom🛡️🛡️🛡️/anm.js'
import {swiftOut,timeout} from '/front/js🧠🧠🧠/🔧utils.js'

// import { getSkin } from '/front/start🏁🏁🏁/load🧱.js'

export class project extends doom {
  constructor(el) {

    // const style = getComputedStyle(document.documentElement)
    

    const mediaQueries = {
    }

    const main = el
    super(mediaQueries,main)


   

  }

  intro( ops = new Map(), resolve = null ){

    //Ops needs
    const first = ops.get('first')
    
    this.DOM = {
      images:this.main.querySelectorAll('.slider_el'),
      left:this.main.querySelector('.slider_left'),
      right:this.main.querySelector('.slider_right'),
    }

  
    this.active = 0
    this.pos = 0

    
    const ANM = anime.createTimeline({
      autoplay:false,
      // delay:first == 1 ? 1 : 0,
      onBegin:()=>{
        this.DOM.images[this.pos].classList.add('act')
        if(this.DOM.images[this.pos].querySelector('video')){
          this.DOM.images[this.pos].querySelector('video').play()
        }
      },
      onComplete:()=>{
        
        resolve != null ? resolve() : null

      }
      
    })
    .add(this.main,{
      opacity:[0,1],
      duration:.6,
      ease:'inOut(2)',
      // composition:'blend',
    },0)
    .init()


    return ANM
  }

  // async getPosts(global){

  //   const DATA = await getSkin(global, 'getPosts')

  // }

  setSCP(){

    //💡 Genera el Scope
    super.setSCP()
    

    this.SCP
    .add(self =>{

        const {
          isPT,
          isMobile,
          isTouch
        } = self.matches


        
        this.DOM.left.onclick = () =>{
          this.DOM.images[this.pos].classList.remove('act')
          if(this.DOM.images[this.pos].querySelector('video')){
            this.DOM.images[this.pos].querySelector('video').pause()
          }
          if(this.pos==0){
            this.pos=this.DOM.images.length-1
          }
          else{
            this.pos--
          }
    
    
          this.DOM.images[this.pos].classList.add('act')
          if(this.DOM.images[this.pos].querySelector('video')){
            this.DOM.images[this.pos].querySelector('video').play()
          }
        }
    
    
        this.DOM.right.onclick = () =>{
          this.DOM.images[this.pos].classList.remove('act')
          if(this.DOM.images[this.pos].querySelector('video')){
            this.DOM.images[this.pos].querySelector('video').pause()
          }
          if(this.pos==this.DOM.images.length-1){
            this.pos=0
          }
          else{
            this.pos++
          }
    
    
          this.DOM.images[this.pos].classList.add('act')
          if(this.DOM.images[this.pos].querySelector('video')){
            this.DOM.images[this.pos].querySelector('video').play()
          }
        }
        

    })



  }

  resizeFn(){
    super.resizeFn()



  }
}
