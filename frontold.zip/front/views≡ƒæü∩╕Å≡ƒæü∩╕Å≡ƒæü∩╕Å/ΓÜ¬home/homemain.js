import {doom} from '/front/doom🛡️🛡️🛡️/doom🛡️'



//ANIMS
import {linesShow,elY100,hovANM} from '/front/doom🛡️🛡️🛡️/anm.js'
import {swiftOut,timeout,debounce} from '/front/js🧠🧠🧠/🔧utils.js'

import { getSkin } from '/front/start🏁🏁🏁/load🧱.js'


import {Sld} from '/front/comps🦾🦾🦾/slider🎞️.js'

export class home extends doom {
  constructor(el) {

    const style = getComputedStyle(document.documentElement)
    

    const mediaQueries = {
    }

    const main = el
    super(mediaQueries,main)


    //DOMs que se repitan 
    this.DOM = {

    }
    
   

  }

  intro( ops = new Map(), resolve = null ){
    // Start intro
    // console.log('launch intro')
    super.intro()
    


    //PARAMS
    const first = ops.get('first')
    
    //ELs que se repitan 
    const ims = this.main.querySelectorAll('.im')


    
   
    const ANM = anime.createTimeline({
      autoplay:false,
      // delay:first == 1 ? 1 : 0,
      onComplete:()=>{
        
        this.setSCP(ops)
        resolve != null ? resolve() : null

        // console.log('complete home Intro')
      }
      
    })
    .add(ims,{
      y:{
        from:'100lvh',
        to:'0lvh',
        onComplete:anime.utils.cleanInlineStyle
      },
      duration:.6,
      ease:'inOut(2)',
      // composition:'replace',
    },1)
    .add(this.main,{
      opacity:[0,1],
      duration:.6,
      ease:'inOut(2)',
      // composition:'replace',
    },0)
    .init()


    console.log('init home Intro')

    // resolve != null ? ANM.play() : null


    if(resolve == null){
      return ANM
    }
    else{
      ANM.init()
    }
  }


  setSCP(ops = new Map()){

    //💡 Genera el Scope
    super.setSCP()

    this.SCP
    .add(self =>{

      const {
        isPT,
        isMobile,
        isTouch
      } = self.matches

      

      const ims = this.main.querySelectorAll('.im'),
      h = window.innerHeight


      for(let im of ims){
        const 
        rand =  anime.utils.randomPick([.4, .5, .2, .8]),
        // rand   =  .4,
        bound  = im.getBoundingClientRect(),
        start  = ((bound.y - window.scrollY) < h) ? 0 : (bound.y - window.scrollY),
        enter  = ((bound.y - window.scrollY) < h) ? 'top '+start : 'bottom '+(bound.y - window.scrollY),
        end    = ((bound.y - window.scrollY) < h) ? (((bound.height * (1. + rand)) + h + Math.max(0,((bound.height*(1. + rand)) + bound.y) - h)) - window.scrollY) : ((bound.y + (bound.height * (1. + rand)) + h) - window.scrollY),
        leave  = ((bound.y - window.scrollY) < h) ? 'bottom '+end : 'bottom '+end


        // console.log(im)
        // console.log(Math.max(0,((bound.height*(1. + rand)) + bound.y) - h))
        // console.log(start+' '+end+' | '+enter+' '+leave+' total :'+(end - start))

        const ANM = anime.animate(im,{
          y:[0+'%',(rand * 100)+'%'],
          duration:1,
          autoplay: anime.onScroll({
            // enter:'top '+(bound.y - window.scrollY),
            enter,
            leave,
            target:document.body,
            ease:'linear',
            sync: .15,
            // debug: true,
          })
        })

      }


    })
    

  }




  resizeFn(){
    super.resizeFn()
  }
}
