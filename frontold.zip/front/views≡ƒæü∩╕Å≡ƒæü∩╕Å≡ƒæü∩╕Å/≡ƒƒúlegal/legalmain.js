import {doom} from '/front/doom🛡️🛡️🛡️/doom🛡️'



//ANIMS
import {linesShow,elY100,hovANM} from '/front/doom🛡️🛡️🛡️/anm.js'
import {swiftOut,timeout} from '/front/js🧠🧠🧠/🔧utils.js'

import { getSkin } from '/front/start🏁🏁🏁/load🧱.js'



export class legal extends doom {
  constructor(el) {

    const style = getComputedStyle(document.documentElement)
    

    const mediaQueries = {
    }

    const main = el
    super(mediaQueries,main)


   

  }

  intro( ops = new Map(), resolve = null ){
    // Start intro
    // console.log('launch intro')
    super.intro()


    const ANM = anime.createTimeline({
      autoplay:false,
      // delay:first == 1 ? 1 : 0,
      onComplete:()=>{
        
        this.setSCP(ops)
        resolve != null ? resolve() : null

      }
      
    })
    .add(this.main,{
      opacity:[0,1],
      duration:.6,
      ease:'inOut(2)',
    },0)
    .init()



    return ANM

  }


  setSCP(){

    


    //💡 Genera el Scope
    super.setSCP()

    const 
    wysis = this.main.querySelectorAll('.wysi'),
    ancs = this.main.querySelectorAll('.anc')


    this.SCP
    .add(self =>{

        const { 
          isMobile,
          isTouch,
          isPT
        } = self.matches


        if(!isPT){


          for(let [i,a] of wysis.entries()){

            anime.animate(ancs[i],{
              autoplay:anime.onScroll({
                target:a,
                enter:'0 -80',
                leave:'top end-=80',
                // debug:true,
                onEnter:()=>{

                  anime.animate(ancs[i],{opacity:.4,duration:.4})
                },
                onLeave:()=>{

                  anime.animate(ancs[i],{opacity:1,duration:.4})

                },
                })
            })

          }



        }

       

    })




  }




  resizeFn(){
    super.resizeFn()



  }
}
