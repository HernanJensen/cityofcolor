import {doom} from '/front/doom🛡️🛡️🛡️/doom🛡️'


import {Sld} from '/front/comps🦾🦾🦾/slider🎞️.js'

//ANIMS
import {linesShow,elY100,hovANM} from '/front/doom🛡️🛡️🛡️/anm.js'
import {swiftOut,timeout} from '/front/js🧠🧠🧠/🔧utils.js'

// import { getSkin } from '/front/start🏁🏁🏁/load🧱.js'

export class works extends doom {
  constructor(el) {

    // const style = getComputedStyle(document.documentElement)
    

    const mediaQueries = {
    }

    const main = el
    super(mediaQueries,main)


   

  }

  intro( ops = new Map(), resolve = null ){

    //Ops needs
    const first = ops.get('first')
    // const lenis = ops.get('lenis')

    this.DOM = {
      
    }
    
    const els = this.el.querySelectorAll('.work_el') 
    const ANM = anime.createTimeline({
      autoplay:false,
      // delay:first == 1 ? 1 : 0,
      onComplete:()=>{

      }
      
    })
    .add(this.el, {
      // y: ['6rem', '0rem'],
      opacity: [0, 1],
      duration: .6,
      ease: 'inOut(3)',
      
    },0)

    .add(els, {
      y: ['6rem', '0rem'],
      // opacity: [0, 1],
      duration: .6,
      ease: 'inOut(3)',
      delay: anime.stagger(.2, {start: 0}),
      
    },0)
    .init()


    
    resolve != null ? ANM.play() : null
  }

  // async getPosts(global){

  //   const DATA = await getSkin(global, 'getPosts')

  // }

  setSCP(){

    //💡 Genera el Scope
    super.setSCP()
    

    this.SCP
    .add(self =>{

        const {
          isPT,
          isMobile,
          isTouch
        } = self.matches


        const footAnm = linesShow(this.DOM.footIn,{autoplay:anime.onScroll({
          target:this.DOM.footIn.parentNode,
          enter:'center top',
          })
        })
        
        const footAnmB = elY100(this.DOM.footInBtn,{delay:1,autoplay:anime.onScroll({
          target:this.DOM.footIn.parentNode,
          enter:'center top',
          })
        })


        if(!isTouch){


          for(let a of this.DOM.aBtns){

            const style = getComputedStyle(a)
            const wBtn = a.clientWidth
            const anmtBtn = hovANM(a)
            a.onmousemove = (ev)=>{
              // console.log(ev)



              anmtBtn['--first']( Math.max(0, ((ev.offsetX - 16) / wBtn) ) )
              anmtBtn['--last']( ev.offsetX / wBtn )


            }


            a.onmouseleave = ()=>{

              anmtBtn['--first'](0)
              anmtBtn['--last'](0)


            }


          }

          if(!isPT){

            // const timeline = anime.createTimeline({autoplay:false,
            //   ease:'none',
              
            // })
            const obj = {ypos:0}
            const lng = this.DOM.mds.length
            // const animatable = anime.createAnimatable(obj,{
            //   ypos:.5,
            //   ease:'inOut(3)',
    
            // })
            // const timer = anime.createTimer({
            //   loop: true,
            //   onUpdate: (self) => {
            //     timeline.seek(obj.ypos)
            //   },
            //   autoplay:anime.onScroll({
            //     // debug: true,
            //     target: this.DOM.listH,
            //     // enter: 'top top-='+((h - this.DOM.listC.clientHeight) * .5),
            //     enter: 'bottom top',
            //     leave: 'top bottom',
                
            //   })
            // })
            const anmMover = anime.createAnimatable(
              this.DOM.mover, {
                'x':.3,
                'y':.3,
                '--timergl':.5,
                ease:'out(1.6)',
            }) 
            

            this.DOM.listH.onmouseenter = (ev) =>{

              anmMover['--timergl'](0)

            }

            this.DOM.listH.onmousemove = (ev) =>{


              const yresta = this.DOM.listH.getBoundingClientRect().y
              const ytotal = ev.screenY - yresta

              
              // console.log(ev.layerY+' screen'+ev.screenY+' page'+ev.pageY+' y'+ev.y+' mov'+ev.movementY)
              anmMover.x(ev.pageX).y(ytotal)
            }
            this.DOM.listH.onmouseleave = (ev) =>{
              anmMover['--timergl'](2)

            }
            // this.DOM.listH.onmouseleave = (ev) =>{
            //   anmMover.x(this.DOM.listH.clientWid).y(ev.offsetY)
            // }

            for(let [i,a] of this.DOM.mds.entries()){

              
              const anmEl = anime.createAnimatable(this.DOM.mdsEl[i],{
                '--timer1':{ unit: '%' },
                '--timer2':.6,
                duration:.6,
                ease:'inOut(3)',
      
              })

              const anmDir = anime.createAnimatable(a.parentNode, {
                  '--transgl':{unit:'%',duration:.2},
              }) 

              // const hel = a.clientHeight * .5

              a.onmouseenter = (ev) =>{
                const ydir = ev.offsetY > a.clientHeight * .5 ? 100 : 0
                // console.log(ydir)
                anmEl['--timer1'](0,.6)
                anmEl['--timer2'](0,.6)
                anmDir['--transgl'](ydir)
              }


              a.onmouseleave = (ev) =>{
                

                const ydir = ev.offsetY > a.clientHeight * .5 ? 100 : 0
                anmDir['--transgl'](ydir)
                anmEl['--timer1'](50,.42)
                anmEl['--timer2'](1,.42)
                anmDir['--transgl'](ydir)
              }


              

            }


            // this.DOM.listH.onmouseleave = () =>{
            //   const pos = Math.round(obj.ypos)
            //   animatable.ypos(pos-1,.4,'out(2.4)')
            //   console.log('ouuut '+pos)
            // }


          }

        }
    })



  }




  resizeFn(){
    super.resizeFn()



  }
}
