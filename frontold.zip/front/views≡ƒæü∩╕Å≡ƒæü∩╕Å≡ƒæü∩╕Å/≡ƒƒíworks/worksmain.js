import {doom} from '/front/doom🛡️🛡️🛡️/doom🛡️'


import {Sld} from '/front/comps🦾🦾🦾/slider🎞️.js'

//ANIMS
import {linesShow,elY100,hovANM} from '/front/doom🛡️🛡️🛡️/anm.js'
import {swiftOut,timeout} from '/front/js🧠🧠🧠/🔧utils.js'
import { stagger } from 'animejs'

// import { getSkin } from '/front/start🏁🏁🏁/load🧱.js'

export class works extends doom {
  constructor(el) {

    // const style = getComputedStyle(document.documentElement)
    

    const mediaQueries = {
    }

    const main = el
    super(mediaQueries,main)


  }

  intro( ops = new Map(), resolve = null ){



    //Ops needs
    const first = ops.get('first')
    // const lenis = ops.get('lenis')
    document.documentElement.classList.remove('dnoneNav')

    

    this.DOM = {
      els : this.main.querySelectorAll('.work_el'),
    }

    
    
    const ANM = anime.createTimeline({
      autoplay:false,
      // delay:first == 1 ? 1 : 0,
      onComplete:()=>{
        
      }
      
    })
    .add(this.main, {
      // y: ['6rem', '0rem'],
      opacity: [0, 1],
      duration: .6,
      ease: 'inOut(3)',
      
    },0)

    .add(this.DOM.els, {
      y: ['6rem', '0rem'], 
      // opacity: [0, 1],
      duration: .6,
      ease: 'inOut(3)',
      delay: anime.stagger(.2, {start: 0}),
      
    },0)
    .init()


    return ANM
    // resolve != null ? ANM.play() : null
  }


  setSCP(){
    //💡 Genera el Scope
    super.setSCP()

    this.SCP
    .add(self =>{

      const {
        isPT,
        isMobile,
        isTouch
      } = self.matches

      // console.log(self)
      
      for (let [i, el] of this.DOM.els.entries()){

        // console.log(el.getBoundingClientRect().y)

        // const start = window.scrollY - el.getBoundingClientRect().y

        // const H = window.innerHeight

        // if(start < H){

        // }
        // else{
          
        // }



        let enter = isPT ?  (i === 0 ? 'top top' : 'top+=40% center') : (i === 0 ? 'center-=10vh top+=50%' : 'bottom top+=50%')
        let leave = 'top bottom+=50%'
 
        anime.animate(el, {
          y: isPT ? ['0%','-45%'] : ['0%','-45%'],
          ease: 'linear',
          autoplay: anime.onScroll({
            enter,
            leave,
            sync: .15,
            // debug: true,
          })
        });
      }

    })

  }




  resizeFn(){
    super.resizeFn()

  }
}
