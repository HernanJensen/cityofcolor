import * as lib from '/front/js🧠🧠🧠/🔧utils.js'


export default class Abtn{
  constructor (el) {
    this.el = el
    // console.log(el)

    this.initEvents()
  }


  initEvents(){
    this.el.onmouseenter = (ev)=>{
      gsap.set(this.el, {'--top': ev.layerY+'px', '--left': ev.layerX+'px'})
    }
    this.el.onmouseleave = (ev)=>{
      gsap.set(this.el, {'--top': ev.layerY+'px', '--left': ev.layerX+'px'})
    }
  }
}