
export async function getSkin(global, func = 'getSkin') {

  //🧹 CLEAN GLOBAL
  if (global.lenis) delete global.lenis
  if (global.SLL) delete global.SLL

  return new Promise((resolve) => {
    // let url = window.location.pathname.replace('.php','')
    let view = import.meta.env.DEV ? window.location.pathname : global

    let url = view
    // url = url.replace('/','')

    if (import.meta.env.DEV == true) {


      view = view.replace('index', '/')
      if (view === '/') {
        view = '//'
      }
      else {
        view = view.replace(/\/$/, "")
      }

      const urlParams = new URL(window.location.href)

      // Por si no tienes ganas de crear phps para development:
      view = urlParams.searchParams.has('uC') ? urlParams.searchParams.get('uC') : view



      //PREVIEW PARA SANITY
      url = import.meta.env.DEV == true ? window.location.origin.replace('1234', '8888') : global.base
      url += '/php/main.php'
    }


    const method = import.meta.env.DEV ? 'POST' : 'GET'

    const headers = import.meta.env.DEV == true ? {
      'Content-Type': 'application/x-www-form-urlencoded',
    }
      : {
        'X-Requested-With': 'XMLHttpRequest'
      }

    const body = import.meta.env.DEV == true ? new URLSearchParams({
      functionToCall: func,
      views: JSON.stringify(view),
      ops: JSON.stringify(global)
    }) : null


    fetch(url, {
      method,
      headers,
      body,
    })
      .then(async (response) => {
        const data = import.meta.env.DEV ? await response.json() : await response.text()
        resolve(data)
      })
      .catch(error => console.error('Error:', error))


  })
}


