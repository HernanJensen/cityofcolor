import * as lib from '/front/js🧠🧠🧠/🔧utils.js'


export default class Upd{
  constructor (el) {



    this.el = el
    
    this.upd = 'UPD'

    
    //💬  El set lo vamos a controlar desde APP.js,
    // así si hay un cambio ( resize a responsive, pasa a touch, etc etc ), se pasa de manera global
    // this.set(ops)
  }
  
  set(OPS){
    // 💡💡💡 Mapa para gestionar el DOM,
    // lo ponemos en el SET porque así, si hay algún cambio se rehace y ya.
    // Con cambio me refiero a si este io tiene dos comportamientos dependiendo del resize,x ej
    this.DOM = new Map([
      ['el',this.el],
      ['key','valor'],
    ])

    //🦶 Marcamos posiciones
    this.setBND()

    //🦶 Si es muy grande el ANM, se puede importar como VAR
    this.ANM = gsap.timeline({paused:true})
    .to(this.el,{width:'+='+60+'vw',duration:1},0)
    
    // 🦶 Lanzar EVTS ( el kill antes es para limpiar )
    // this.killEVT()
    // this.setEVT(OPS)
    
  }

  kill(){
    // 💡💡💡 Mata todos los procesos del IO
    this.active = 0
    // this.killEVT()
  
  }

  chkFn(entry,pos){
    let CHK = false
    
    if(entry.isIntersecting==undefined){
      //🦶 aquí incluso se puede hacer algo por si se esconde un IO ( para eso el height 0)
      
      CHK = undefined
    }
    else if(entry.isIntersecting==true){
      //🦶 IN
      CHK = this.start(entry)

    }
    else{
      //🦶 OUT
      CHK = this.stop(entry)

    }

    return CHK


  }
  
  start(){
    if(this.active == 1){
      return true
    }
    this.active = 1
   
    return true
  }
  
  stop(entry){
    // 💡💡💡
    // Por si el lerp no ha terminado, la irse de pantalla
    let PRG = 0
    let CRT = 0

    if(this.active == 0){
      return false
    }
    this.active = 0
   
    if(entry.boundingClientRect.y < 0){
      PRG = 1
      CRT = this.BND.get(1)

    }
    else{
      PRG = 0
      CRT = this.BND.get(0)
      
    }

    gsap.to(this.ANM,{progress:PRG,duration:.2,

      onComplete:()=>{
        this.BND.set('CRT',CRT)

        this.BND.set('PRG',PRG)
        this.BND.set('PRGt',PRG)
        
      }
    })

    return false
  }

  setEVT(){
   
  }

  updFn(SCLLy = window.scrollY,VEL = 0){
    // 💡💡💡 Calcular,
    //  de serie no hay que lerpearlo porque va con la velocidad del scroll
    // Si se quiere lerpear, se puede para hacer un efecto más lento.
    if(this.active == 0 || !this.ANM){
      return false
    }

    //🦶 Aligeramos pasos, y lo que nos interesa en el clamp es lo 2º, el 1º y el 3º son limits
    this.BND.set('CRT',
    lib.clamp(
      0,
      this.BND.get(1),
      (SCLLy + this.SCR[1]) - this.BND.get(0),
    ))
    
    //🦶 calc progreso, el fixed 8 es porque si no da saltitos, a las muy malas, quitar
    this.BND.set('PRGt',
     parseFloat(
      (
        this.BND.get('CRT')  / this.BND.get(1)
      )
    ))
    

    this.BND.set('PRG',
    (lib.lerp(
      this.BND.get('PRG') , 
      this.BND.get('PRGt') , 
      .4
      // .04
    ))

   )
   

    //🦶 Animar hasta
    this.ANM.progress( this.BND.get('PRG') )

  }

  setBND(SCLLy = window.scrollY){
    //🦶 Posiciones, tamaños, etc
    // Start 0         End (limit )    1    
    // current CRT     Progress PRG      Progress target PRGt   
    const h = window.innerHeight
    const BND = this.el.getBoundingClientRect()
    const start = parseInt((BND.y + SCLLy))
    const limit =  BND.height

    this.BND = new Map([
      [0,start],
      [1,limit],
      ['CRT',0],
      ['PRG',0],
      ['PRGt',0]
    ])

    this.SCR = [window.innerWidth,window.innerHeight]

  }

  resizeFn(SCLLy = window.scrollY,OPS){
    // 💡💡💡 


    if(this.ANM){
    //🦶 Resetear ANM, no siempre es necesario, pero si se deja fino, 
    // automatizado es cómodo.

      //🦶 Mata el gsap
      this.ANM.kill()
      //🦶 Reseta el IOS ( crea el map, la animación, etc)
      this.set(OPS)
      //🦶 Darle el valor que tenía.
      this.updFn(SCLLy,0)
    
    }

    
  }
  
}
